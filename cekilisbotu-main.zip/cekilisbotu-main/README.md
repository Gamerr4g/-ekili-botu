# cekilis-botu

Bu bot çoğu yeri Türkçe yapılmış bir çekiliş botudur.

## discord.gg/safecode

## Discord: HAPPY#2401
